/**
 * @file course.c
 * @author Roxanne Li (lix268@mcmaster.ca)
 * @date 2022/4/11
 * @brief Functions for generating attributes associated with a course such as 
 *        the number of students enrolled, its top student and students who passed the course, etc.
 *
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/** 
 * Given a couse and a student, add the student to the list of students enrolled in this course,
 * increment the total_students by 1.
 * 
 * We use calloc to allocate memory for adding the first student to the course if there is no previously added student
 * We use realloc to allocate additional memory for adding a student to the course if the couse already had 
 * at least one student enrolled.
 * 
 * @param course, a pointer to a course object that is typedef struct
 * @param student, a pointer to a student object that is typedef struct
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Given a course, print its attributes including its name, code, total_num_of_students, and 
 * the information of all the students.
 * 
 * @param course, a pointer to a course object that is typedef struct
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/** 
 * Given a course, return the student with the highest average grade in this course 
 * 
 * Use a for loop to loop through all the students in the course to find the maximum average grade
 * 
 * @param course, a pointer to a course object that is typedef struct
 * @return the top student with the highest average grade
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/** 
 * Given a course, return a list of students whose average grades passed 50
 * 
 * First, loop through the students in the couse to count how many of them have average grade > 50, 
 *    set total_passing = count
 * Second, loop through the students again and add the students who passed 50 to the list "passing"
 * 
 * @param course, a pointer to a course object that is typedef struct.
 * @param total_passing, a pointer to a memory where we store the number of students who passed the course.
 * 
 * @return the top student with the highest average grade
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}