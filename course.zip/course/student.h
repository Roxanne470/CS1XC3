/**
 * @file student.h
 * @author Roxanne Li (lix268@mcmaster.ca)
 * @date 2022/4/11
 * @brief Student library including student type definition, and functions for 
 *        generating attributes associated with a student such as name, id, grades, average grade, etc.
 *
 */


/**
* Student type stores a student with fields first & last name, id, grades, num_grades
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's id */
  double *grades; /**< the student's grades */
  int num_grades; /**< the student's number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
