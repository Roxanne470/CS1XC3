/**
 * @file student.c
 * @author Roxanne Li (lix268@mcmaster.ca)
 * @date 2022/4/11
 * @brief Functions for generating attributes associated with a student such as 
 *        name, id, grades, etc.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** 
 * Given a student object and his/her grade, add the new grade to his/her list of grades
 * 
 * We use calloc to allocate memory for storing the student's first grade if there is no previously stored grade
 * We use realloc to allocate additional memory for storing the student's new grade if the student already had 
 * at least one grade stored.
 * 
 * @param student, a pointer to a student object that is typedef struct
 * @param grade, the student's new grade
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/** 
 * Given a student, return his/her average grade
 * 
 * Use a for loop to loop through the student's grades, calculate the sum and then the average
 * 
 * @param student, a pointer to a student object that is typedef struct
 * @return the student's average grade calculated
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/** 
 * Given a student, print his/her attributes including the calculated average grade
 * 
 * @param student, a pointer to a student object that is typedef struct.
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * Given an integer, generate a new student object with first and last name randomly chosen,
 *        the 10-digit id is also randomly generated with each digit generated using (char) ((rand() % 10) + 48);
 *        Suppose the integer given is 3, the student will have 3 new grades generated using
 *        (double) (25 + (rand() % 75)).
 * 
 * @param grades, number of grades the newly generated student will have
 * @return a student object with some attributes
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}