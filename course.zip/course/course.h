/**
 * @file course.h
 * @author Roxanne Li (lix268@mcmaster.ca)
 * @date 2022/4/11
 * @brief Course library including course type definition, and functions for 
 *        generating attributes associated with a course such as students, top student, passing students.
 *
 */


/**
* Course type stores a course with fields name, code, enrolled students, total number of students
*
*/
#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100]; /**< the course's name */
  char code[10]; /**< the course's code */
  Student *students; /**< the course's enrolled students information */
  int total_students; /**< number of students enrolled */
} Course;

void enroll_student(Course *course, Student *student); 
void print_course(Course *course); 
Student *top_student(Course* course); 
Student *passing(Course* course, int *total_passing); 

